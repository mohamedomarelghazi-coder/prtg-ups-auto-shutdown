@echo off
REM Triggered by PRTG when the sensor turns YELLOW (mains lost, running on battery).
"C:\Windows\System32\OpenSSH\ssh.exe" -i "C:\PRTGKey\ssh.txt" -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL -o BatchMode=yes prtgups@192.168.56.10 mains_lost >> C:\PRTGKey\prtg_debug.log 2>&1
